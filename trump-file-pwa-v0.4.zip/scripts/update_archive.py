#!/usr/bin/env python3
"""
Trump File discovery updater.

Purpose:
- Pull *new source material* into data/candidates.json.
- Never automatically call an item false, dumb, corrupt, contradictory, etc.
- Never increment the public archive counter merely because a page was discovered.
- Primary government documents can be represented as source candidates automatically.
- Editorial publication happens by moving a reviewed candidate into entries.json.

Uses only Python stdlib so it can run in GitHub Actions.
"""
import json, urllib.request, urllib.parse, datetime, pathlib, re, xml.etree.ElementTree as ET

ROOT=pathlib.Path(__file__).resolve().parents[1]
CAND=ROOT/"data"/"candidates.json"
ENT=ROOT/"data"/"entries.json"
UA={"User-Agent":"TrumpFileArchive/0.3 (+public research archive)"}

def get(url):
    req=urllib.request.Request(url,headers=UA)
    with urllib.request.urlopen(req,timeout=30) as r: return r.read()

def load(p): return json.loads(p.read_text())
def save(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+"\n")

def federal_register():
    # Federal Register API. Search second-term Trump executive orders.
    params={
      "per_page":"1000",
      "order":"newest",
      "conditions[president][]":"donald-trump",
      "conditions[presidential_document_type][]":"executive_order",
      "conditions[publication_date][gte]":"2025-01-20"
    }
    url="https://www.federalregister.gov/api/v1/documents.json?"+urllib.parse.urlencode(params,doseq=True)
    payload=json.loads(get(url))
    out=[]
    for d in payload.get("results",[]):
        out.append({
          "key":"fr:"+d.get("document_number",""),
          "discoveredFrom":"Federal Register",
          "date":d.get("publication_date"),
          "title":d.get("title"),
          "url":d.get("html_url"),
          "kind":"presidential_document",
          "sourceTier":"primary",
          "status":"candidate",
          "editorialNote":"Government action discovered automatically. Decide whether it belongs in the satirical archive; do not infer a negative judgment from discovery alone."
        })
    return out

def whitehouse_feed():
    # WordPress-style feed currently used by White House Presidential Actions.
    raw=get("https://www.whitehouse.gov/presidential-actions/feed/")
    root=ET.fromstring(raw)
    out=[]
    for item in root.findall(".//item"):
        title=(item.findtext("title") or "").strip()
        link=(item.findtext("link") or "").strip()
        pub=(item.findtext("pubDate") or "").strip()
        out.append({
          "key":"wh:"+link,
          "discoveredFrom":"White House Presidential Actions",
          "dateRaw":pub,
          "title":title,
          "url":link,
          "kind":"presidential_action",
          "sourceTier":"primary",
          "status":"candidate",
          "editorialNote":"Primary-source discovery. Review context and corroboration before converting into a public archive entry."
        })
    return out

def main():
    state=load(CAND); existing={c["key"] for c in state.get("candidates",[]) if c.get("key")}
    found=[]
    errors=[]
    for fn in (federal_register,whitehouse_feed):
        try: found.extend(fn())
        except Exception as e: errors.append(f"{fn.__name__}: {e}")
    fresh=[x for x in found if x["key"] not in existing]
    state.setdefault("candidates",[]).extend(fresh)
    state["lastDiscoveryRun"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
    state["lastErrors"]=errors
    state["newCandidates"]=len(fresh)
    save(CAND,state)
    print(f"Discovered {len(fresh)} new candidates. Errors: {errors or 'none'}")

if __name__=="__main__": main()
