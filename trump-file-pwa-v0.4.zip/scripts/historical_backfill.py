#!/usr/bin/env python3
"""
Trump File historical source crawler.

Builds a large *source archive* and candidate review queue from:
  1) Federal Register presidential documents since Jan 20, 2025
  2) White House Presidential Actions
  3) White House Remarks

Important:
- Source archive != verified satirical incidents.
- Discovery never labels an item false, foolish, corrupt, contradictory, etc.
- Reviewed public incidents remain in data/entries.json.
"""
from __future__ import annotations
import json, urllib.request, urllib.parse, datetime, pathlib, re, time
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=ROOT/"data"/"source_archive.json"
CAND=ROOT/"data"/"candidates.json"
UA={"User-Agent":"TrumpFileArchive/0.4 public-research-index"}

def get_text(url, timeout=45):
    req=urllib.request.Request(url,headers=UA)
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return r.read().decode("utf-8","replace")

def load(path, default):
    try: return json.loads(path.read_text())
    except Exception: return default

def save(path,obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")

def strip_html(s):
    s=re.sub(r"<script\b.*?</script>"," ",s,flags=re.I|re.S)
    s=re.sub(r"<style\b.*?</style>"," ",s,flags=re.I|re.S)
    s=re.sub(r"<[^>]+>"," ",s)
    return re.sub(r"\s+"," ",s).strip()

def federal_register_all():
    docs=[]
    page=1
    while True:
        params={
          "per_page":"1000","page":str(page),"order":"oldest",
          "conditions[president][]":"donald-trump",
          "conditions[publication_date][gte]":"2025-01-20"
        }
        url="https://www.federalregister.gov/api/v1/documents.json?"+urllib.parse.urlencode(params,doseq=True)
        payload=json.loads(get_text(url))
        results=payload.get("results",[])
        for d in results:
            docs.append({
              "key":"fr:"+str(d.get("document_number","")),
              "date":d.get("publication_date"),
              "title":d.get("title"),
              "url":d.get("html_url"),
              "source":"Federal Register",
              "sourceTier":"primary",
              "kind":(d.get("type") or "presidential_document").lower().replace(" ","_"),
              "documentNumber":d.get("document_number"),
              "executiveOrderNumber":d.get("executive_order_number")
            })
        if page >= int(payload.get("total_pages") or 1): break
        page += 1
        time.sleep(.2)
    return docs

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower()=="a":
            d=dict(attrs); href=d.get("href")
            if href:self.links.append(href)

def page_links(url, prefix):
    html=get_text(url)
    p=LinkParser();p.feed(html)
    out=[]
    for href in p.links:
        u=urljoin(url,href).split("#")[0]
        if u.startswith(prefix) and u.rstrip("/") != prefix.rstrip("/"):
            out.append(u)
    return list(dict.fromkeys(out)),html

def crawl_listing(base_url, item_prefix, kind, max_pages=260):
    found={}
    empty_streak=0
    for page in range(1,max_pages+1):
        url=base_url if page==1 else f"{base_url.rstrip('/')}/page/{page}/"
        try:
            links,html=page_links(url,item_prefix)
        except Exception as e:
            if page>3: break
            continue
        item_links=[u for u in links if re.search(r"/20(25|26)/\d{2}/",u)]
        if not item_links:
            empty_streak += 1
            if empty_streak>=2: break
        else: empty_streak=0
        for u in item_links:
            found[u]={
              "key":"wh:"+u,
              "url":u,
              "source":"White House",
              "sourceTier":"primary",
              "kind":kind
            }
        print(kind,"page",page,"total",len(found))
        time.sleep(.15)
    return list(found.values())

def enrich_whitehouse(items):
    # Fetch each article only enough to derive title/date from its HTML.
    for i,item in enumerate(items,1):
        try:
            html=get_text(item["url"])
            m=re.search(r"<h1[^>]*>(.*?)</h1>",html,re.I|re.S)
            if not m:m=re.search(r"<title[^>]*>(.*?)</title>",html,re.I|re.S)
            item["title"]=strip_html(m.group(1))[:500] if m else item["url"].rstrip("/").split("/")[-1].replace("-"," ").title()
            dm=re.search(r"/(2025|2026)/(\d{2})/",item["url"])
            # Prefer machine-readable YYYY-MM-DD in page.
            exact=re.search(r'\b(202[56]-\d{2}-\d{2})\b',html)
            item["date"]=exact.group(1) if exact else (f"{dm.group(1)}-{dm.group(2)}-01" if dm else None)
        except Exception as e:
            item["title"]=item["url"].rstrip("/").split("/")[-1].replace("-"," ").title()
            item["crawlError"]=str(e)
        if i%50==0: print("enriched",i,"/",len(items))
        time.sleep(.08)
    return items

def main():
    records={}
    errors=[]
    try:
        for x in federal_register_all(): records[x["key"]]=x
    except Exception as e: errors.append("Federal Register: "+repr(e))

    wh=[]
    for base,prefix,kind in [
      ("https://www.whitehouse.gov/presidential-actions/","https://www.whitehouse.gov/presidential-actions/","presidential_action"),
      ("https://www.whitehouse.gov/remarks/","https://www.whitehouse.gov/remarks/","remark")
    ]:
        try: wh += crawl_listing(base,prefix,kind)
        except Exception as e: errors.append(kind+": "+repr(e))
    try: wh=enrich_whitehouse(wh)
    except Exception as e: errors.append("White House enrichment: "+repr(e))
    for x in wh: records[x["key"]]=x

    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    source={"generatedAt":now,"count":len(records),"records":sorted(records.values(),key=lambda x:(x.get("date") or "",x.get("title") or "")),"errors":errors}
    save(SOURCE,source)

    state=load(CAND,{"candidates":[]})
    existing={c.get("key") for c in state.get("candidates",[])}
    fresh=[]
    for r in source["records"]:
        if r["key"] not in existing:
            fresh.append({
              **r,
              "status":"candidate",
              "editorialNote":"Machine-discovered primary-source material. Review context and relevance before publishing as a verified satirical archive entry."
            })
    state.setdefault("candidates",[]).extend(fresh)
    state["lastHistoricalRun"]=now
    state["historicalSourceCount"]=len(records)
    state["newCandidatesFromHistoricalRun"]=len(fresh)
    state["lastErrors"]=errors
    save(CAND,state)
    print("SOURCE RECORDS:",len(records))
    print("NEW CANDIDATES:",len(fresh))
    print("ERRORS:",errors or "none")

if __name__=="__main__": main()
