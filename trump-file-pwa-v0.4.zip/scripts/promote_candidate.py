#!/usr/bin/env python3
"""Interactive helper: promote a reviewed candidate to the public archive after you edit its fields."""
import json,pathlib,sys,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
c=json.loads((ROOT/"data/candidates.json").read_text())
a=json.loads((ROOT/"data/entries.json").read_text())
if len(sys.argv)<2:
 print("Usage: python scripts/promote_candidate.py <candidate-key>");raise SystemExit(2)
key=sys.argv[1]
cand=next((x for x in c["candidates"] if x.get("key")==key),None)
if not cand: raise SystemExit("Candidate not found")
nid=max([e["id"] for e in a["entries"]]+[0])+1
entry={"id":nid,"date":cand.get("date") or datetime.date.today().isoformat(),"type":"policy","category":"REVIEW ME","satiricalTitle":"WRITE SATIRICAL TITLE","summary":cand["title"],"context":"ADD MATERIAL CONTEXT BEFORE PUBLISHING","verdict":"verified","sourceTier":cand.get("sourceTier","primary"),"tags":[],"sources":[{"label":cand["discoveredFrom"],"url":cand["url"]}]}
out=ROOT/"data"/f"review-{nid}.json"
out.write_text(json.dumps(entry,indent=2)+"\n")
print("Review file created:",out)
